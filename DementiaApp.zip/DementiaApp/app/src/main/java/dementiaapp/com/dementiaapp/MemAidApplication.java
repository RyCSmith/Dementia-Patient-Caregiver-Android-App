package dementiaapp.com.dementiaapp;

import android.app.Application;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import se.emilsjolander.sprinkles.Migration;
import se.emilsjolander.sprinkles.Sprinkles;

/**
 * Main Application. Launches the Program.
 */
public class MemAidApplication extends Application {

        @Override
        public void onCreate() {
            super.onCreate();
        }
    }
